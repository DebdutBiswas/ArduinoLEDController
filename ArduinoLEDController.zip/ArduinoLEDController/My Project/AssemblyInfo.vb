﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("LED Controller")> 
<Assembly: AssemblyDescription("Arduino LED Controller")> 
<Assembly: AssemblyCompany("Dev Software Development")> 
<Assembly: AssemblyProduct("Arduino LED Controller")> 
<Assembly: AssemblyCopyright("Copyright © Dev Software Development 2015")> 
<Assembly: AssemblyTrademark("Dev Software Development")> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("ef472aba-15bf-44c3-8a43-6e25f95bdd4c")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 

<Assembly: NeutralResourcesLanguageAttribute("en-US")> 